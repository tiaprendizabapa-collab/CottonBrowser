'use strict';
const DEFAULTS = {
  enabledSites: [], cosmeticSites: [], dialogModes: {}, autoCinemaSites: []
};
function siteKey(raw) {
  try {
    const u = new URL(raw);
    return /^(https?:)$/.test(u.protocol) ? `${u.protocol}//${u.hostname}` : null;
  } catch { return null; }
}
async function settings() { return chrome.storage.local.get(DEFAULTS); }
async function getTabState(tabId) {
  const tab = await chrome.tabs.get(tabId);
  const key = siteKey(tab.url || tab.pendingUrl || '');
  const s = await settings();
  const enabled = !!key && s.enabledSites.includes(key);
  return {
    ok: true, siteKey: key, enabled,
    cosmetic: enabled && s.cosmeticSites.includes(key),
    dialogMode: enabled ? (s.dialogModes[key] || 'known') : 'off',
    version: chrome.runtime.getManifest().version
  };
}
async function scriptIds(key) {
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(key));
  const id = Array.from(new Uint8Array(bytes)).map(n => n.toString(16).padStart(2,'0')).join('').slice(0,24);
  return ['s113_' + id + '_main','s113_' + id + '_cinema'];
}
async function registerSite(key) {
  const ids = await scriptIds(key);
  const current = await chrome.scripting.getRegisteredContentScripts();
  const old = current.filter(s => ids.includes(s.id)).map(s => s.id);
  if (old.length) await chrome.scripting.unregisterContentScripts({ids:old});
  await chrome.scripting.registerContentScripts([
    {id:ids[0],matches:[key+'/*'],js:['block-main.js','dialog-guard.js'],runAt:'document_start',world:'MAIN',allFrames:false,persistAcrossSessions:true},
    {id:ids[1],matches:[key+'/*'],js:['cinema.js'],runAt:'document_idle',world:'ISOLATED',allFrames:false,persistAcrossSessions:true}
  ]);
}
async function unregisterSite(key) {
  const ids = await scriptIds(key);
  const current = await chrome.scripting.getRegisteredContentScripts();
  const remove = current.filter(s => ids.includes(s.id)).map(s => s.id);
  if (remove.length) await chrome.scripting.unregisterContentScripts({ids:remove});
}
async function initialize() {
  const s = await chrome.storage.local.get(null);
  if (s.migrated113 !== true) {
    // A fresh recovery starts without automatic cinema or cosmetic guesses.
    await chrome.storage.local.set({migrated113:true, cosmeticSites:[], dialogModes:{}, autoCinemaSites:[]});
  }
  const current = await chrome.scripting.getRegisteredContentScripts();
  if (current.length) await chrome.scripting.unregisterContentScripts({ids:current.map(x => x.id)});
  const data = await settings();
  for (const key of data.enabledSites) {
    if (siteKey(key) === key) await registerSite(key);
  }
}
const ready = initialize().catch(e => console.error('BC113 initialization:', e));
async function installDialogs(sender, state) {
  if (!state.enabled || state.dialogMode === 'off') return;
  if (sender.tab?.id == null) return;
  // Target the SAME document which asked for state, avoiding navigation races.
  const target = sender.documentId
    ? {tabId:sender.tab.id,documentIds:[sender.documentId]}
    : {tabId:sender.tab.id,frameIds:[sender.frameId || 0]};
  await chrome.scripting.executeScript({target,world:'MAIN',files:['dialog-guard.js']});
  await chrome.scripting.executeScript({
    target, world:'MAIN', args:[state.dialogMode],
    func: mode => window.__BC_DIALOGS_113__?.configure(mode)
  });
}
async function popupTab(msg, sender) {
  // Only the extension popup may alter settings; content scripts cannot nominate tabs.
  if (sender.tab || !Number.isInteger(msg.tabId)) throw new Error('Operacao nao autorizada.');
  return chrome.tabs.get(msg.tabId);
}
async function dispatch(msg, sender) {
  await ready;
  if (msg?.type === 'frameState113') {
    if (sender.tab?.id == null) return {ok:false};
    const state = await getTabState(sender.tab.id);
    if (state.enabled && state.dialogMode !== 'off') {
      try { await installDialogs(sender, state); state.dialogReady = true; }
      catch (e) { state.dialogReady = false; state.dialogError = String(e); }
    }
    return state;
  }
  const tab = await popupTab(msg, sender);
  const key = siteKey(tab.url || tab.pendingUrl || '');
  if (msg.type === 'getState113') return getTabState(tab.id);
  if (!key) throw new Error('Abra uma pagina HTTP ou HTTPS.');
  const s = await settings();
  if (msg.type === 'activate113') {
    await chrome.storage.local.set({enabledSites:[...new Set([...s.enabledSites,key])]});
    await registerSite(key);
    await chrome.tabs.reload(tab.id);
    return {ok:true};
  }
  if (msg.type === 'deactivate113') {
    await chrome.storage.local.set({enabledSites:s.enabledSites.filter(x=>x!==key)});
    await unregisterSite(key);
    await chrome.tabs.reload(tab.id);
    return {ok:true};
  }
  if (!s.enabledSites.includes(key)) throw new Error('Ative a extensao neste site primeiro.');
  if (msg.type === 'setCosmetic113') {
    const set = new Set(s.cosmeticSites);
    msg.enabled ? set.add(key) : set.delete(key);
    await chrome.storage.local.set({cosmeticSites:[...set]});
    await chrome.tabs.reload(tab.id);
    return {ok:true};
  }
  if (msg.type === 'setDialog113') {
    if (!['known','all','off'].includes(msg.mode)) throw new Error('Modo invalido.');
    await chrome.storage.local.set({dialogModes:{...s.dialogModes,[key]:msg.mode}});
    await chrome.tabs.reload(tab.id);
    return {ok:true};
  }
  if (msg.type === 'recovery113') {
    await chrome.storage.local.set({
      cosmeticSites:s.cosmeticSites.filter(x=>x!==key),
      dialogModes:{...s.dialogModes,[key]:'off'}, autoCinemaSites:[]
    });
    await chrome.tabs.reload(tab.id);
    return {ok:true};
  }
  if (msg.type === 'cinema113') {
    // Inject only the original cinema code, not blockers or cleaners.
    await chrome.scripting.executeScript({target:{tabId:tab.id},world:'ISOLATED',files:['cinema.js']});
    await chrome.tabs.sendMessage(tab.id,{type:'toggleCinema'},{frameId:0});
    return {ok:true};
  }
  if (msg.type === 'diagnostics113') {
    const state = await getTabState(tab.id);
    const frames = await chrome.scripting.executeScript({
      target:{tabId:tab.id,allFrames:true},world:'ISOLATED',
      func: () => ({
        origin:location.origin, readyState:document.readyState,
        iframes:document.querySelectorAll('iframe').length,
        playerArea:!!document.querySelector('.player-area'),
        cleaner:window.__BC_CLEANER_113__?.stats() || null,
        bridge:window.__BC_STATE_113__ || null,
        videos:[...document.querySelectorAll('video')].map(v=>({
          readyState:v.readyState, networkState:v.networkState,
          paused:v.paused, mediaError:v.error?.code || null
        }))
      })
    });
    const dialogs = await chrome.scripting.executeScript({
      target:{tabId:tab.id,allFrames:true},world:'MAIN',
      func:()=>({origin:location.origin,dialogs:window.__BC_DIALOGS_113__?.stats() || null})
    });
    return {ok:true,report:{extension:chrome.runtime.getManifest().name,state,
      frames:frames.map(f=>({frameId:f.frameId,...f.result})),
      dialogs:dialogs.map(f=>({frameId:f.frameId,...f.result}))}};
  }
  throw new Error('Comando desconhecido.');
}
chrome.runtime.onMessage.addListener((msg,sender,respond) => {
  dispatch(msg,sender).then(respond).catch(e=>respond({ok:false,error:String(e)}));
  return true;
});
chrome.tabs.onCreated.addListener(tab=> {
  (async()=>{
    await ready;
    if (tab.openerTabId == null || tab.id == null) return;
    if ((await getTabState(tab.openerTabId)).enabled) await chrome.tabs.remove(tab.id);
  })().catch(()=>{});
});
chrome.commands.onCommand.addListener(command=> {
  if (command !== 'toggle-cinema') return;
  (async()=>{
    await ready;
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if (!tab?.id || !(await getTabState(tab.id)).enabled) return;
    await chrome.scripting.executeScript({target:{tabId:tab.id},world:'ISOLATED',files:['cinema.js']});
    await chrome.tabs.sendMessage(tab.id,{type:'toggleCinema'},{frameId:0});
  })().catch(e=>console.warn('BC113 cinema:',e));
});
