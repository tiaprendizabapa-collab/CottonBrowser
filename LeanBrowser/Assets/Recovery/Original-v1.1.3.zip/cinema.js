(() => {
  if (window.top !== window) return;
  if (window.__MODO_CINEMA_ABAPA_CARREGADO__) return;
  window.__MODO_CINEMA_ABAPA_CARREGADO__ = true;

  let active = false;
  let player = null;
  let backdrop = null;
  let savedPlayerStyle = null;
  let savedHtmlOverflow = "";
  let savedBodyOverflow = "";
  let savedAncestorStyles = [];

  function visibleRect(el) {
    try {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      if (
        r.width < 240 ||
        r.height < 120 ||
        s.display === "none" ||
        s.visibility === "hidden" ||
        Number(s.opacity) === 0
      ) return null;
      return r;
    } catch {
      return null;
    }
  }

  function findPlayer() {
    const videos = [...document.querySelectorAll("video")]
      .map(el => ({ el, r: visibleRect(el) }))
      .filter(x => x.r)
      .sort((a, b) => (b.r.width * b.r.height) - (a.r.width * a.r.height));

    if (videos.length) return videos[0].el;

    const iframes = [...document.querySelectorAll("iframe")]
      .map(el => ({ el, r: visibleRect(el) }))
      .filter(x => x.r)
      .sort((a, b) => (b.r.width * b.r.height) - (a.r.width * a.r.height));

    if (iframes.length) return iframes[0].el;

    const generic = [...document.querySelectorAll(
      '[class*="player"], [id*="player"], [class*="video"], [id*="video"]'
    )]
      .map(el => ({ el, r: visibleRect(el) }))
      .filter(x => x.r)
      .sort((a, b) => (b.r.width * b.r.height) - (a.r.width * a.r.height));

    return generic[0]?.el || null;
  }

  function saveAndNeutralizeAncestors(el) {
    savedAncestorStyles = [];
    let p = el.parentElement;

    while (p && p !== document.body && p !== document.documentElement) {
      savedAncestorStyles.push({
        el: p,
        style: p.getAttribute("style")
      });

      p.style.setProperty("transform", "none", "important");
      p.style.setProperty("filter", "none", "important");
      p.style.setProperty("perspective", "none", "important");
      p.style.setProperty("contain", "none", "important");
      p.style.setProperty("overflow", "visible", "important");
      p.style.setProperty("clip", "auto", "important");
      p.style.setProperty("clip-path", "none", "important");
      p.style.setProperty("z-index", "2147483647", "important");

      p = p.parentElement;
    }
  }

  function restoreAncestors() {
    for (const item of savedAncestorStyles) {
      if (!item.el?.isConnected) continue;

      if (item.style === null) item.el.removeAttribute("style");
      else item.el.setAttribute("style", item.style);
    }

    savedAncestorStyles = [];
  }

  function enterCinema() {
    if (active) return;

    player = findPlayer();
    if (!player) {
      console.info("[Modo Cinema] Nenhum vídeo/iframe grande foi encontrado.");
      return;
    }

    active = true;
    savedPlayerStyle = player.getAttribute("style");
    savedHtmlOverflow = document.documentElement.style.overflow;
    savedBodyOverflow = document.body?.style.overflow || "";

    saveAndNeutralizeAncestors(player);

    backdrop = document.createElement("div");
    backdrop.id = "__modo_cinema_backdrop__";
    Object.assign(backdrop.style, {
      position: "fixed",
      inset: "0",
      width: "100vw",
      height: "100vh",
      margin: "0",
      padding: "0",
      background: "#000",
      zIndex: "2147483646",
      pointerEvents: "none"
    });

    (document.body || document.documentElement).appendChild(backdrop);

    document.documentElement.style.setProperty("overflow", "hidden", "important");
    if (document.body) {
      document.body.style.setProperty("overflow", "hidden", "important");
    }

    const rules = {
      position: "fixed",
      top: "0",
      left: "0",
      right: "auto",
      bottom: "auto",
      width: "100vw",
      height: "100vh",
      maxWidth: "none",
      maxHeight: "none",
      minWidth: "0",
      minHeight: "0",
      margin: "0",
      padding: "0",
      border: "0",
      borderRadius: "0",
      transform: "none",
      objectFit: "contain",
      background: "#000",
      zIndex: "2147483647"
    };

    for (const [k, v] of Object.entries(rules)) {
      player.style.setProperty(
        k.replace(/[A-Z]/g, m => "-" + m.toLowerCase()),
        v,
        "important"
      );
    }
  }

  function exitCinema() {
    if (!active) return;

    active = false;

    try {
      if (player?.isConnected) {
        if (savedPlayerStyle === null) player.removeAttribute("style");
        else player.setAttribute("style", savedPlayerStyle);
      }
    } catch (_) {}

    try { backdrop?.remove(); } catch (_) {}

    document.documentElement.style.overflow = savedHtmlOverflow;
    if (document.body) document.body.style.overflow = savedBodyOverflow;

    restoreAncestors();

    player = null;
    backdrop = null;
    savedPlayerStyle = null;
  }

  function toggleCinema() {
    if (active) exitCinema();
    else enterCinema();
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "toggleCinema") toggleCinema();
    if (msg?.type === "enterCinema") enterCinema();
    if (msg?.type === "exitCinema") exitCinema();
  });

  // Alt+V is handled only by chrome.commands, avoiding two toggles per keypress.
  window.addEventListener("keydown", (event) => {


    if (event.key === "Escape" && active) {
      exitCinema();
    }
  }, true);

  chrome.storage.local.get({ autoCinemaSites: [] }, (data) => {
    const siteKey = `${location.protocol}//${location.hostname}`;
    if (data.autoCinemaSites.includes(siteKey)) {
      setTimeout(() => enterCinema(), 700);
    }
  });
})();
