(() => {
  'use strict';
  if (window.__BC_BRIDGE_113__) return;
  window.__BC_BRIDGE_113__=true;
  chrome.runtime.sendMessage({type:'frameState113'},state=>{
    if (chrome.runtime.lastError || !state?.ok) return;
    window.__BC_STATE_113__={
      enabled:state.enabled,cosmetic:state.cosmetic,
      dialogMode:state.dialogMode,dialogReady:!!state.dialogReady
    };
    const configure=()=>window.__BC_CLEANER_113__?.configure(state.enabled && state.cosmetic);
    configure();
    // Both files share the same isolated world; no web-page messages are trusted.
    setTimeout(configure,0);
    document.addEventListener('DOMContentLoaded',configure,{once:true});
  });
})();
