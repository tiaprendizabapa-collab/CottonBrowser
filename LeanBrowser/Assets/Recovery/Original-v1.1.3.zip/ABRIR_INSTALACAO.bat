@echo off
setlocal EnableExtensions
title Bloqueio e Cinema 1.1.3 - Instalar
cd /d "%~dp0"
if not exist "%~dp0manifest.json" (
  echo Extraia o ZIP inteiro antes de executar este arquivo.
  pause
  exit /b 1
)
echo.
echo Pasta da extensao:
echo %~dp0
echo.
echo No Chrome:
echo 1. Desative as versoes antigas DESTA extensao.
echo 2. Ative Modo do desenvolvedor.
echo 3. Clique Carregar sem compactacao e selecione esta pasta.
echo.
echo Este BAT so abre as janelas. Ele nao forca a instalacao.
start "" explorer.exe "%~dp0"
set "CHROME="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined CHROME if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined CHROME if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" set "CHROME=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
if defined CHROME (
  start "" "%CHROME%" "chrome://extensions/"
) else (
  echo Abra o Chrome e digite chrome://extensions/ na barra de endereco.
)
echo.
pause
exit /b 0
