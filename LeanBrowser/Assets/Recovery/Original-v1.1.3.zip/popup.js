'use strict';
const $=id=>document.getElementById(id);
let tab=null,busy=false;
async function message(type,extra={}) {
  const r=await chrome.runtime.sendMessage({type,tabId:tab.id,...extra});
  if (!r?.ok) throw new Error(r?.error || 'Nao foi possivel executar. Recarregue a extensao e a pagina.');
  return r;
}
async function run(action,close=true) {
  if (busy) return;
  busy=true; $('error').textContent='';
  try { await action(); if(close) window.close(); }
  catch(e){$('error').textContent=String(e.message || e);}
  finally{busy=false;}
}
$('activate').onclick=()=>run(()=>message('activate113'));
$('deactivate').onclick=()=>run(()=>message('deactivate113'));
$('cosmetic').onchange=()=>run(()=>message('setCosmetic113',{enabled:$('cosmetic').checked}));
$('dialogs').onchange=()=>run(()=>message('setDialog113',{mode:$('dialogs').value}));
$('cinema').onclick=()=>run(()=>message('cinema113'));
$('recovery').onclick=()=>run(()=>message('recovery113'));
$('diagnostics').onclick=()=>run(async()=>{
  const r=await message('diagnostics113');
  const text=JSON.stringify(r.report,null,2);
  try{await navigator.clipboard.writeText(text);$('error').textContent='Diagnostico copiado. Cole na conversa.';}
  catch{
    const area=document.createElement('textarea');area.value=text;area.style.cssText='width:100%;height:140px';
    document.body.appendChild(area);area.focus();area.select();
    $('error').textContent='Pressione Ctrl+C para copiar o texto selecionado.';
  }
},false);
(async()=>{
  [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if (!tab?.id) throw new Error('Nenhuma guia ativa.');
  const s=await message('getState113');
  $('host').textContent=s.siteKey || 'Abra uma pagina HTTP ou HTTPS.';
  $('status').textContent=s.enabled ? 'Ativo neste site. Sem notificacoes de bloqueio.' : 'Desativado neste site.';
  $('activate').hidden=s.enabled;$('activate').disabled=!s.siteKey;
  $('deactivate').hidden=!s.enabled;
  for(const id of ['dialogs','cosmetic','cinema','recovery','diagnostics']) $(id).disabled=!s.enabled;
  $('dialogs').value=s.dialogMode==='off' && !s.enabled ? 'known':s.dialogMode;
  $('cosmetic').checked=!!s.cosmetic;
})().catch(e=>{$('error').textContent=String(e.message||e);});
