(() => {
  if (window.__BLOQUEIO_SILENCIOSO_ATIVO__) return;

  Object.defineProperty(window, "__BLOQUEIO_SILENCIOSO_ATIVO__", {
    value: true,
    configurable: false,
    enumerable: false,
    writable: false
  });

  const blockedOpen = function () {
    return null;
  };

  // Bloqueia a forma mais comum de propaganda/pop-under.
  try {
    Object.defineProperty(window, "open", {
      configurable: false,
      enumerable: true,
      get: () => blockedOpen,
      set: () => {}
    });
  } catch (_) {
    try { window.open = blockedOpen; } catch (_) {}
  }

  function isNewTarget(target) {
    const t = String(target || "").toLowerCase();
    return t === "_blank" || t === "_new";
  }

  function externalUrl(href) {
    try {
      return new URL(href, location.href).origin !== location.origin;
    } catch {
      return true;
    }
  }

  // Cliques reais do usuário.
  document.addEventListener("click", (event) => {
    const node = event.target;
    const a = node?.closest?.("a[href]");

    if (!a || !isNewTarget(a.getAttribute("target"))) return;

    // Link interno pode continuar, mas na MESMA guia.
    if (!externalUrl(a.href)) {
      try { a.setAttribute("target", "_self"); } catch (_) {}
      return;
    }

    // Link externo em nova guia: bloqueia completamente.
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
  }, true);

  // Formulários tentando abrir outra guia.
  document.addEventListener("submit", (event) => {
    const form = event.target;
    if (!form || !isNewTarget(form.getAttribute?.("target"))) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
  }, true);

  // Cliques disparados por JavaScript em <a target="_blank">.
  try {
    const originalClick = HTMLAnchorElement.prototype.click;
    HTMLAnchorElement.prototype.click = function (...args) {
      if (isNewTarget(this.getAttribute("target"))) {
        if (externalUrl(this.href)) return;
        try { this.setAttribute("target", "_self"); } catch (_) {}
      }
      return originalClick.apply(this, args);
    };
  } catch (_) {}
})();
